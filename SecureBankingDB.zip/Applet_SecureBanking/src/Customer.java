/*
.------..------.
|J.--. ||H.--. |
| :(): || :/\: |
| ()() || (__) |
| '--'J|| '--'H|
`------'`------'
Name: Janet Hardiman
Date: 16/01/17
Project: Applet

Build on an example by Mark Pendergast
*/
import java.io.Serializable;

public class Customer implements Serializable{
    String debtorName = "";
    String mandateID = "";
    String language = "";
    String IBAN = "";
    String BIC = "";
    String currency = "";
    String date= "";
    String amount = "";

    /**
     * 
     *  Default constructor
     */
    public Customer()
    {
        
    }
     /**
     *  working constructor
     * @param dn debtor name
     * @param m mandateID
     * @param l language
     * @param i IBAN
     * @param b BIC
     * @param c currency
     * @param d date
     * @param a amount
     */
    public Customer(String dn, String m, String l, String i, String b, String c, String d, String a)
    {
        debtorName = dn;
        mandateID = m;
        language = l;
        IBAN = i;
        BIC = b;
        currency = c;
        date = d;
        amount = a;
    }
    /**
     *  Converts object to a string
     * @return String
     */
    
    @Override
    public String toString()
    {
        return  " : "+ mandateID + ", " + debtorName + ", " + language + ", " + IBAN + ", " + BIC + ", " + currency + ", " + date + ", " + amount;
    }
}
