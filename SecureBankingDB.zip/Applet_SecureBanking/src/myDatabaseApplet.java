/*
.------..------.
|J.--. ||H.--. |
| :(): || :/\: |
| ()() || (__) |
| '--'J|| '--'H|
`------'`------'
Name: Janet Hardiman
Date: 16/01/17
Project: Applet
*/

import java.applet.AppletContext;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Currency;
import javax.swing.*;
import javax.swing.text.MaskFormatter;

public class myDatabaseApplet extends javax.swing.JApplet {

    //J.Variables declaration
    private JPanel topPanel;

    private JLabel idLabel;
    private JTextField idField;
    private JLabel debtorNameLabel;
    private JTextField debtorNameField;
    private JLabel mandateLabel;
    private JTextField mandateField;
    private JLabel languageLabel;
    private JTextField languageField;
    private JLabel IBANLabel;
    private JTextField IBANField;
    private JLabel BICLabel;
    private JTextField BICField;

    private JPanel bottomPanel;
    private JPanel button1Panel;
    private JTabbedPane tabbedPane;
    private JPanel button2Panel;

    //button1 Panel
    private JButton addButton;
    private JButton clearButton;
    private JButton findButton;
    private JTextField findField;

    //tabbedPane
    private JLabel currencyLabel;
    private JFormattedTextField currencyField;
    private JLabel dateLabel;
    private JFormattedTextField dateField;
    private JLabel amountLabel;
    private JFormattedTextField amountField;

    //button2 Panel
    private JButton addDebit;
    private JButton clrDebit;
    private JButton genXML;

    private JLabel msgLbl;

    /**
     * Initializes the applet
     */
    @Override
    public void init() {
        

        /* Create and display the applet */
        try {
            java.awt.EventQueue.invokeAndWait(new Runnable() {  //invoke later
                public void run() {
                    try {
                        initComponents();
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }

                }
            });
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    /**
     * setMessageLabel
     * <p>
     * changes the text in the message label at the bottom of the applet.
     *
     * @param msg String to be placed in the message label
     */
    public void setMessageLabel(String msg) {
        msgLbl.setText(msg);
    }

    private void initComponents() throws ParseException {
        setSize(600, 500);

        Container content = getContentPane();
        content.setLayout(new GridLayout(2,1,25,25));
        topPanel = new JPanel();
        topPanel.setLayout(new GridLayout(5,1,5,5));
        bottomPanel = new JPanel();
        bottomPanel.setLayout(new BorderLayout());

        mandateLabel = new JLabel("Mandate ID:");
        debtorNameLabel = new JLabel("Debtor Name:");
        languageLabel = new JLabel("Debtor Language:");
        IBANLabel = new JLabel("IBAN:");
        BICLabel = new JLabel("BIC:");

        mandateField = new JTextField();
        debtorNameField = new JTextField();
        languageField = new JTextField();
        IBANField = new JTextField();
        BICField = new JTextField();

        button1Panel = new JPanel();

        tabbedPane = new JTabbedPane();

        currencyLabel = new JLabel("Currency:");
        dateLabel = new JLabel("Date: (yyyymmdd)");
        amountLabel = new JLabel("Amount:");

        NumberFormat format = NumberFormat.getCurrencyInstance(getLocale());
        Currency currency = format.getCurrency();
        currencyField = new JFormattedTextField(currency);

        MaskFormatter dateMask = new MaskFormatter("####-##-##");
        dateMask.setPlaceholderCharacter('_');
        dateField = new JFormattedTextField(dateMask);

        MaskFormatter amountMask = new MaskFormatter("#,###.##");
        amountMask.setPlaceholderCharacter('_');
        amountField = new JFormattedTextField(amountMask);


        //tabbed panel #1
        JComponent panel1 = makeTextPanel("");
        panel1.setPreferredSize(new Dimension(200, 500));
        tabbedPane.addTab("Debits", null, panel1,
                "Does nothing");
        tabbedPane.addTab("+", new JPanel());
        tabbedPane.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                int total = tabbedPane.getTabCount();
                int last = total - 1;
                if(tabbedPane.getSelectedIndex() == last){
                    tabbedPane.remove(last);
                    JComponent panel1 = makeTextPanel("");
                    panel1.setPreferredSize(new Dimension(200, 500));
                    tabbedPane.addTab("Debits", null, panel1,
                        "Does nothing");
                    tabbedPane.addTab("+", new JPanel());
                }
            }
        });


        addButton = new JButton("ADD");
        addButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
                    clearButton.setEnabled(true);
                    addDebit.setEnabled(true);
                    setMessageLabel("add button pressed");

                    // public Customer( String dn, String m, String l, String i, String b, String c, String d, String a)
                    Customer c = new Customer(debtorNameField.getText(), mandateField.getText(), languageField.getText(),
                            IBANField.getText(), BICField.getText(), currencyField.getText(),
                            dateField.getText(), amountField.getText());

                    System.out.println(c);
                    System.out.println(getCodeBase() + "AddCustomer");
                    URL link = new URL(getCodeBase() + "AddCustomer");
                    System.out.println(getCodeBase() + "AddCustomer");


                    setMessageLabel("Processing request ...");
                    HttpURLConnection urlconnection = (HttpURLConnection) link.openConnection();

                    urlconnection.setDoOutput(true);
                    urlconnection.setDoInput(true);
                    urlconnection.setUseCaches(false);
                    urlconnection.setDefaultUseCaches(false);

                    // Specify the content type that we will send binary data
                    urlconnection.setRequestProperty("Content-Type", "application/octet-stream");

                    ObjectOutputStream oos = new ObjectOutputStream(urlconnection.getOutputStream());
                    oos.writeObject(c);  // send the customer
                    oos.flush();

                    ObjectInputStream ois = new ObjectInputStream(urlconnection.getInputStream());
                    int count = ois.readInt();  // read back the number of rows deleted
                    oos.close();
                    ois.close();

                    setMessageLabel("Record added");
                    System.out.println(c);

                    JOptionPane.showMessageDialog(
                            content, "Client added.");

                } catch (Exception ex) {
                    //setMessageLabel("Unable to process request : "+ex.toString());
                }
            }
        });


        clearButton = new JButton("CLEAR");
        clearButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
                    //resultsLbl.setVisible(false);
                    addButton.setEnabled(true);
                    debtorNameField.setText("");
                    mandateField.setText("");
                    languageField.setText("");
                    IBANField.setText("");
                    BICField.setText("");

                    findField.setText("");
                    setMessageLabel("Fields cleared");
                    JOptionPane.showMessageDialog(
                            content, "Details fields cleared.");
                    clearButton.setEnabled(false);
                    addDebit.setEnabled(false);

                } catch (Exception ex) {
                    // setMessageLabel("Unable to process request : "+ex.toString());
                }
            }
        });

        findButton = new JButton("SEARCH:");
        findButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
                    //DefaultTableModel tm = (DefaultTableModel)resultsTable.getModel();
                    addButton.setEnabled(false);
                    clearButton.setEnabled(true);
                    addDebit.setEnabled(true);
                    debtorNameField.setText("");
                    mandateField.setText("");
                    languageField.setText("");
                    IBANField.setText("");
                    BICField.setText("");

                    String Name = findField.getText();
                    // setMessageLabel(lastName+" last name");

                    URL link = new URL(getCodeBase() + "FindCustomer");
                    setMessageLabel("Processing request ...");
                    HttpURLConnection urlconnection = (HttpURLConnection) link.openConnection();
                    setMessageLabel("connection open");
                    urlconnection.setDoOutput(true);
                    urlconnection.setDoInput(true);
                    urlconnection.setUseCaches(false);
                    urlconnection.setDefaultUseCaches(false);

                    // Specify the content type that we will send binary data
                    urlconnection.setRequestProperty("Content-Type", "application/octet-stream");

                    ObjectOutputStream oos = new ObjectOutputStream(urlconnection.getOutputStream());
                    setMessageLabel("after oos");

                    oos.writeObject(Name);


                    ObjectInputStream ois = new ObjectInputStream(urlconnection.getInputStream());
                    setMessageLabel("after ois");

                    Customer c = (Customer) ois.readObject();
                    setMessageLabel("received object");

                    if (c.debtorName.length() == 0) {  // empty id indicates last customer
                        setMessageLabel("=0");
                        JOptionPane.showMessageDialog(
                                content, "Client not found");
                    } else {
                        setMessageLabel("  in else" + c.debtorName);

                        debtorNameField.setText(c.debtorName);
                        mandateField.setText(c.mandateID);
                        languageField.setText(c.language);
                        IBANField.setText(c.IBAN);
                        BICField.setText(c.BIC);

                        setMessageLabel(" Record found ");
                        JOptionPane.showMessageDialog(
                                content, "Client found.");
                    }

                    oos.close();
                    ois.close();

                } catch (Exception ex) {
                    setMessageLabel(msgLbl.getText() + " error: " + ex.toString());
                }
            }
        });

        findField = new JTextField("", 20);

        button2Panel = new JPanel();
        addDebit = new JButton("add Debit");
        addDebit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
                    clrDebit.setEnabled(true);
                    genXML.setEnabled(true);
                    setMessageLabel("add debit pressed");

                    String date = dateField.getText();
                    String amount = amountField.getText();

                    if((date.contains( "__")) || (amount.endsWith(".__"))){
                        setMessageLabel("All fields must be completed first!");
                        JOptionPane.showMessageDialog(
                                content, "All fields must be completed first!");
                    }

                    else {
                        // public Customer( String dn, String m, String l, String i, String b, String c, String d, String a)
                        Customer c = new Customer(debtorNameField.getText(), mandateField.getText(), languageField.getText(),
                                IBANField.getText(), BICField.getText(), currencyField.getText(),
                                dateField.getText(), amountField.getText());

                        System.out.println(c);
                        System.out.println(getCodeBase() + "AddDebit");
                        URL link = new URL(getCodeBase() + "AddDebit");


                        setMessageLabel("Processing request ...");
                        HttpURLConnection urlconnection = (HttpURLConnection) link.openConnection();

                        urlconnection.setDoOutput(true);
                        urlconnection.setDoInput(true);
                        urlconnection.setUseCaches(false);
                        urlconnection.setDefaultUseCaches(false);

                        // Specify the content type that we will send binary data
                        urlconnection.setRequestProperty("Content-Type", "application/octet-stream");

                        ObjectOutputStream oos = new ObjectOutputStream(urlconnection.getOutputStream());
                        oos.writeObject(c);  // send the customer
                        oos.flush();

                        ObjectInputStream ois = new ObjectInputStream(urlconnection.getInputStream());
                        int count = ois.readInt();  // read back the number of rows deleted
                        oos.close();
                        ois.close();

                        setMessageLabel("Debit added");
                        System.out.println(c);
                    }

                } catch (Exception ex) {
                    //setMessageLabel("Unable to process request : "+ex.toString());
                }
            }
        });

        clrDebit = new JButton("clear Debits");
        clrDebit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
                    currencyField.setText("EUR");
                    dateField.setText("");
                    amountField.setText("");

                    setMessageLabel("Fields cleared");
                    JOptionPane.showMessageDialog(
                            content, "Details fields cleared.");
                    clrDebit.setEnabled(false);
                    genXML.setEnabled(false);

                } catch (Exception ex) {
                    // setMessageLabel("Unable to process request : "+ex.toString());
                }
            }
        });
        genXML = new JButton("Generate XML");
        genXML.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                try {
                    setMessageLabel("Generate XML pressed");
                    // public Customer( String dn, String m, String l, String i, String b, String c, String d, String a)
                    Customer c = new Customer(debtorNameField.getText(), mandateField.getText(), languageField.getText(),
                            IBANField.getText(), BICField.getText(), currencyField.getText(),
                            dateField.getText(), amountField.getText());

                    System.out.println(c);
                    System.out.println(getCodeBase() + "GenXML");
                    URL link = new URL(getCodeBase() + "GenXML");
                    System.out.println(getCodeBase() + "GenXML");


                    setMessageLabel("Processing request ...");
                    HttpURLConnection urlconnection = (HttpURLConnection) link.openConnection();

                    urlconnection.setDoOutput(true);
                    urlconnection.setDoInput(true);
                    urlconnection.setUseCaches(false);
                    urlconnection.setDefaultUseCaches(false);

                    // Specify the content type that we will send binary data
                    urlconnection.setRequestProperty("Content-Type", "application/octet-stream");

                    ObjectOutputStream oos = new ObjectOutputStream(urlconnection.getOutputStream());
                    oos.writeObject(c);  // send the customer
                    oos.flush();

                    ObjectInputStream ois = new ObjectInputStream(urlconnection.getInputStream());
                    int count = ois.readInt();  // read back the number of rows deleted


                    setMessageLabel("XML Generated");
                    System.out.println(c);

                    oos.close();
                    ois.close();

                    //default icon, custom title
                    int xml = JOptionPane.showConfirmDialog(
                            content,
                            "Would you like to download the xml file?",
                            "XML File Created",
                            JOptionPane.YES_NO_OPTION);


                    if (xml == JOptionPane.YES_OPTION) {
                        AppletContext a = getAppletContext();
                        System.out.println(getCodeBase() + "DownloadFileServlet");
                        URL link1 = new URL(getCodeBase() + "DownloadFileServlet");
                        System.out.println(getCodeBase() + "DownloadFileServlet");
                        a.showDocument(link1, "_blank");
                        setMessageLabel("Processing request ...");
                        HttpURLConnection urlconnection1 = (HttpURLConnection) link1.openConnection();

                        urlconnection1.setDoOutput(true);
                        urlconnection1.setDoInput(true);
                        urlconnection1.setUseCaches(false);
                        urlconnection1.setDefaultUseCaches(false);

                        // Specify the content type that we will send binary data
                        urlconnection1.setRequestProperty("Content-Type", "application/octet-stream");

                        setMessageLabel("File Downloaded");

                        currencyField.setText("");
                        dateField.setText("");
                        amountField.setText("");

                    } else if (xml == JOptionPane.NO_OPTION) {

                    }


                /*    //read in xml document
                    BufferedReader in = new BufferedReader(new InputStreamReader(
                            urlconnection.getInputStream()));
                    String inputLine;
                    while ((inputLine = in.readLine()) != null)
                        System.out.println(inputLine);
                    in.close();

                    JFileChooser fileChooser = new JFileChooser();
                    fileChooser.setDialogTitle("Specify a file to save");

                    int userSelection = fileChooser.showSaveDialog(content);

                    if (userSelection == JFileChooser.APPROVE_OPTION) {
                        File fileToSave = fileChooser.getSelectedFile();
                        System.out.println("Save as file: " + fileToSave.getAbsolutePath());
                    }*/
                    oos.close();
                    ois.close();

                    //pop up message to add date to enter more than one debit to XML
                /*    String date = JOptionPane.showInputDialog(content, "Enter Processing Dates of Debits: (yyyymmdd)", "XML file generator", JOptionPane.QUESTION_MESSAGE);

                    if ((date != null) && (date.length() > 0)){
                        URL link = new URL(getCodeBase() + "FindCustomer");
                        setMessageLabel("Processing request ...");
                        HttpURLConnection urlconnection = (HttpURLConnection) link.openConnection();
                        setMessageLabel("connection open");
                        urlconnection.setDoOutput(true);
                        urlconnection.setDoInput(true);
                        urlconnection.setUseCaches(false);
                        urlconnection.setDefaultUseCaches(false);

                        // Specify the content type that we will send binary data
                        urlconnection.setRequestProperty("Content-Type", "application/octet-stream");

                        ObjectOutputStream oos = new ObjectOutputStream(urlconnection.getOutputStream());
                        setMessageLabel("after oos");

                        oos.writeObject(date);
                    }
                    setMessageLabel("XML generated");
                    JOptionPane.showMessageDialog(
                            content, "XML file generated.");*/

                } catch (Exception ex) {
                    // setMessageLabel("Unable to process request : "+ex.toString());
                }
            }
        });

        msgLbl = new JLabel();
        //disable some buttons until required
        clearButton.setEnabled(false);
        addDebit.setEnabled(false);
        clrDebit.setEnabled(false);
        genXML.setEnabled(false);

        topPanel.add(debtorNameLabel);
        topPanel.add(debtorNameField);
        topPanel.add(mandateLabel);
        topPanel.add(mandateField);
        topPanel.add(languageLabel);
        topPanel.add(languageField);
        topPanel.add(IBANLabel);
        topPanel.add(IBANField);
        topPanel.add(BICLabel);
        topPanel.add(BICField);

        button1Panel.add(addButton);
        button1Panel.add(clearButton);
        button1Panel.add(findButton);
        button1Panel.add(findField);
        button2Panel.add(addDebit);
        button2Panel.add(clrDebit);
        button2Panel.add(genXML);
        button2Panel.add(msgLbl);
        bottomPanel.add(button1Panel, BorderLayout.NORTH);
        bottomPanel.add(tabbedPane, BorderLayout.CENTER);
        bottomPanel.add(button2Panel, BorderLayout.SOUTH);
        content.add(topPanel);
        content.add(bottomPanel);

    }
    protected JComponent makeTextPanel(String text) {
        JPanel panel = new JPanel(false);

        panel.setLayout(new GridLayout(3,2,10,10));
        panel.add(currencyLabel);
        panel.add(currencyField);
        panel.add(dateLabel);
        panel.add(dateField);
        panel.add(amountLabel);
        panel.add(amountField);
        return panel;
    }
}
