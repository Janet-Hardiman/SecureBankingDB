Add and find working for : Debtor Name: Mandate ID: Debtor Language: IBAN: BIC:
Add debit also working
both clears working
generate XML working - creating xml file in out>artifacts>web_war_exploded!
enable and disable buttons as appropiate
download XML working - only option to save to downloads! might be my system

check that add date and amount are completed before add Debits to database

Added in a login page first to take you to the applet: username: admin password: 1234

WORKING AS REQUIRED FOR NOW!

haven't completed find for all debits entered