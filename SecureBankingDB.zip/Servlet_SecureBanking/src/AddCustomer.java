/*
.------..------.
|J.--. ||H.--. |
| :(): || :/\: |
| ()() || (__) |
| '--'J|| '--'H|
`------'`------'
Name: Janet Hardiman
Date: 16/01/17
Project: Servlet - AddCustomer

Build on an example by Mark Pendergast
*/

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "AddCustomer", urlPatterns = {"/AddCustomer"})
public class AddCustomer extends HttpServlet {

    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request  servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        int count = 0;
        response.setContentType("application/octet-stream");
        InputStream in = request.getInputStream();
        ObjectInputStream ois = new ObjectInputStream(in);
        OutputStream outstr = response.getOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(outstr);
        try {

            Customer c = (Customer) ois.readObject();
            System.out.println(c);
            if (c != null) {
                String driver = "com.mysql.jdbc.Driver";
                String url = "jdbc:mysql://localhost:3306/securebanking";
                Class.forName(driver);  // load the driver
                Connection con = DriverManager.getConnection(url, "root", "");

                PreparedStatement sqlPersonID = con.prepareStatement("select last_insert_id()");

                PreparedStatement sqlInsertName = con.prepareStatement("INSERT INTO names ( debtorName, debtorLanguage, mandateID ) " +
                        "VALUES ( ? , ? , ?)");
                sqlInsertName.setString(1, c.debtorName);
                sqlInsertName.setString(2, c.language);
                sqlInsertName.setString(3, c.mandateID);
                count = sqlInsertName.executeUpdate();
                sqlInsertName.close();

                ResultSet resultPersonID = sqlPersonID.executeQuery();
                if (resultPersonID.last()) {
                    int personID = resultPersonID.getInt(1);
                    System.out.println(personID);

                    PreparedStatement sqlInsertAccount = con.prepareStatement(
                            "INSERT INTO accountdetails ( personID, iban, bic ) " +
                                    "VALUES ( ? , ? , ?   )");
                    sqlInsertAccount.setInt(1, personID);
                    sqlInsertAccount.setString(2, c.IBAN);
                    sqlInsertAccount.setString(3, c.BIC);
                    count = sqlInsertAccount.executeUpdate();
                    sqlInsertAccount.close();

                    con.close();
                }
            }
        } catch (Exception ex) {
            System.out.println(ex.toString());

        } finally {
            oos.writeInt(count);
            oos.flush();
            oos.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
