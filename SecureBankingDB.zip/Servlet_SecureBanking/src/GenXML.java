/*
.------..------.
|J.--. ||H.--. |
| :(): || :/\: |
| ()() || (__) |
| '--'J|| '--'H|
`------'`------'
Name: Janet Hardiman
Date: 16/01/17
Project: Servlet - GenXML
*/

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Mark Pendergast
 */
@WebServlet(name = "GenXML", urlPatterns = {"/GenXML"})
public class GenXML extends HttpServlet {
    //company details
    String ID = "IE04ZZZ306092";
    String PmtInfId = "CRCUR06122016IE58SBANK86436879651R0A";
    String PmtMtd = "DD";
    String BtchBookg = "false";
    String NbOfTxs = "1";
    String Cd = "SEPA";
    String cd1 = "CORE";
    String SeqTp = "RCUR";
    String Company = "Croi Na Ong";
    String Ctry = "IE";
    String Address = "Corrandulla";
    String IBAN = "IE58SBANK86436879651374";
    String BIC = "SBANKIE2D";
    String ChrgBr = "SLEV";
    String EndtoEnd = "981903F9-386E-47DD-A";
    public static String path;

    public static void setPath(String path) {
        GenXML.path = GenXML.path;
    }

    public static String getPath() {
        return path;
    }

    /**
     * Processes requests for both HTTP
     * <code>GET</code> and
     * <code>POST</code> methods.
     *
     * @param request  servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException      if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        System.out.println("in gen xml");
        int count = 0;
        Calendar now = Calendar.getInstance();
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
        System.out.println("It is now : " + formatter.format(now.getTime()));

        SimpleDateFormat sdt = new SimpleDateFormat("yyyyMMddHHmmss");
        String myDate = sdt.format(now.getTime());

        SimpleDateFormat sd = new SimpleDateFormat("yyyy-MM-dd");
        String myDate2 = sd.format(now.getTime());

        response.setContentType("application/octet-stream");
        InputStream in = request.getInputStream();
        ObjectInputStream ois = new ObjectInputStream(in);
        OutputStream outstr = response.getOutputStream();
        ObjectOutputStream oos = new ObjectOutputStream(outstr);
        try {

            Customer c = (Customer) ois.readObject();
            System.out.println("in servlet" + c);
            path = getServletContext().getRealPath("WEB-INF/../"+ myDate + "CCRCpain008.xml");
            setPath(path);
            File file = new File(path);
            System.out.println(path);
            if (file.createNewFile()) {
                System.out.println("File is created!");
            } else {
                System.out.println("File already exists.");
            }


            //company details:
            try {
                FileWriter writer = new FileWriter(path, false);//true means append to file
                writer.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
                writer.write("\r\n");
                writer.write("\t<Document xmlns=\"urn:iso:std:iso:20022:tech:xsd:pain.008.001.02\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">\r\n");
                writer.write("\t\t<CstmrDrctDbtInitn><GrpHdr><MsgId>" + sdt.format(now.getTime()) + "</MsgId><CreDtTm>" + formatter.format(now.getTime()) + "</CreDtTm><NbOfTxs>" + NbOfTxs + "</NbOfTxs><CtrlSum>" + c.amount + "</CtrlSum><InitgPty><Id><PrvtId><Othr><Id>" + ID + "</Id></Othr></PrvtId></Id></InitgPty></GrpHdr>" +
                                   "<PmtInf><PmtInfId>" + PmtInfId + "</PmtInfId><PmtMtd>" + PmtMtd + "</PmtMtd><BtchBookg>" + BtchBookg + "</BtchBookg><NbOfTxs>" + NbOfTxs + "</NbOfTxs><CtrlSum>" + c.amount + "</CtrlSum><PmtTpInf><SvcLvl><Cd>" + Cd + "</Cd></SvcLvl><LclInstrm><Cd>" + cd1 +"</Cd></LclInstrm><SeqTp>" + SeqTp + "</SeqTp></PmtTpInf><ReqdColltnDt>" + myDate2 + "</ReqdColltnDt><Cdtr><Nm>" + Company + "</Nm><PstlAdr><Ctry>" + Ctry + "</Ctry><AdrLine>" + Address + "</AdrLine><AdrLine>" + Address + "</AdrLine></PstlAdr></Cdtr><CdtrAcct><Id><IBAN>" + IBAN + "</IBAN></Id></CdtrAcct><CdtrAgt><FinInstnId><BIC>" + BIC + "</BIC></FinInstnId></CdtrAgt><ChrgBr>" + ChrgBr + "</ChrgBr>\r\n");
                writer.write("\t\t<DrctDbtTxInf><PmtId><EndToEndId>" + EndtoEnd + "</EndToEndId></PmtId><InstdAmt Ccy=\"" + c.currency + "\">" + c.amount + "</InstdAmt><DrctDbtTx><MndtRltdInf><MndtId>" + c.mandateID + "</MndtId><DtOfSgntr>" + c.date + "</DtOfSgntr><AmdmntInd>" + BtchBookg + "</AmdmntInd></MndtRltdInf><CdtrSchmeId><Id><PrvtId><Othr><Id>" + ID + "</Id><SchmeNm><Prtry>" + Cd + "</Prtry></SchmeNm></Othr></PrvtId></Id></CdtrSchmeId></DrctDbtTx><DbtrAgt><FinInstnId><BIC>" + c.BIC + "</BIC></FinInstnId></DbtrAgt><Dbtr><Nm>Client1</Nm></Dbtr><DbtrAcct><Id><IBAN>" + c.IBAN + "</IBAN></Id></DbtrAcct></DrctDbtTxInf></CstmrDrctDbtInitn>\r\n");
                writer.write("\t</Document>\r\n");
                writer.close();
            } catch (IOException e) {
                System.out.println(e.toString());
            }

        } catch (Exception ex) {
            System.out.println(ex.toString());

        } finally {
            oos.writeInt(count);
            oos.flush();
            oos.close();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP
     * <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP
     * <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
