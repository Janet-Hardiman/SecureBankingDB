use secureBanking
;

drop table accountDetails
;
drop table paymentDetails
;
drop table names
;


create table names (
	personID int AUTO_INCREMENT,
	debtorName varchar (50) NOT NULL,
	debtorLanguage varchar (50) NOT NULL,
	mandateID varchar (20),
	constraint pk_name primary key (personID)
) 
;
create table accountDetails (
	accountID int AUTO_INCREMENT,
        personID int NOT NULL,
	iban varchar (50),
	bic varchar (50),
	county varchar (30),
	constraint fk_accountDetails foreign key (personID)
		references names (personID),
	constraint pk_accountDetails primary key (accountID)
) 
;
create table paymentDetails (
	paymentID int AUTO_INCREMENT,
        personID int NOT NULL,
	currency varchar (20),
	collectionAmount float,  
	collectionDate date,
	constraint fk_paymentDetails foreign key (personID)
		references names (personID),
	constraint pk_paymentDetails primary key (paymentID)
) 
;